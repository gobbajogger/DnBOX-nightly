from pathlib import Path
import hashlib, json, socket, subprocess, sys, time
from urllib.request import urlopen
from urllib.error import HTTPError, URLError
with socket.socket() as sock:
    sock.bind(('127.0.0.1',0))
    port=sock.getsockname()[1]
base=f'http://127.0.0.1:{port}'
server=subprocess.Popen([sys.executable,'tests/visual/serve_source.py',str(port)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
rows=[]
try:
    for _ in range(100):
        try:
            with urlopen(base+'/product-site/builds/index.html',timeout=1) as r: break
        except URLError: time.sleep(.05)
    else: raise RuntimeError('source server did not start')
    for route,file in [('builds/index.html','web/product-site/builds/index.html'),('package-version-assignments.json','package-version-assignments.json'),('hardware-tests.json','web/product-site/hardware-tests.json'),('versions.json','web/product-site/versions.json')]:
        with urlopen(base+'/product-site/'+route) as r:
            raw=r.read()
            assert r.status==200 and raw==Path(file).read_bytes()
            rows.append(dict(route=route,http=200,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
    for route in ['/product-site/no-such-assignment.json','/package-version-assignments.json']:
        try: urlopen(base+route)
        except HTTPError as e: assert e.code==404;rows.append(dict(route=route,http=e.code))
        else: raise AssertionError('unknown route served')
finally:
    server.terminate()
    server.wait(timeout=10)
print(json.dumps(rows,indent=2))
