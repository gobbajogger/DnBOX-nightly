"""Run one unchanged registered case on its original built product using its normal page setup."""
import asyncio
import importlib.util
import json
from pathlib import Path
import sys
import time
from playwright.async_api import async_playwright
root=Path(__file__).resolve().parent / sys.argv[1]
name=sys.argv[2]
spec=importlib.util.spec_from_file_location('registered_case', root/'tests/product-remote/funkybeats-browser.py')
suite=importlib.util.module_from_spec(spec)
spec.loader.exec_module(suite)
suite.SOURCE=root/'.output/fb'
assert 'Permission is hereby granted' in (root/'LICENSES/FunkyBeats-MIT.md').read_text()

async def main():
    async with async_playwright() as pw:
        browser=await pw.chromium.launch(chromium_sandbox=True)
        try:
            context=await browser.new_context(viewport={'width':844,'height':390},has_touch=True)
            await context.route('**/*',suite.serve)
            page=await context.new_page()
            errors=[]
            page.on('pageerror',lambda e:errors.append(str(e)))
            await page.add_init_script('navigator.requestMIDIAccess=()=>{throw Error("Device access forbidden in local draft test")};')
            await page.goto(suite.ORIGIN+'/remote/')
            await page.wait_for_function('document.getElementById("status").textContent.includes("Draft")')
            start=time.monotonic()
            print('START',name,'Chrome',browser.version,'actual product',suite.SOURCE,flush=True)
            try:
                await getattr(suite,name)(page)
            except Exception:
                print('Action-state snapshot',await page.evaluate("""()=>({status:document.querySelector('#status')?.textContent,menuOpen:document.querySelector('.overflow')?.open,engine:document.querySelector('[data-engine][aria-pressed=true]')?.dataset.engine,tabLabels:[...document.querySelectorAll('[data-view]')].map(n=>[n.dataset.view,n.getBoundingClientRect().toJSON()])})"""),flush=True)
                raise
            assert not errors,errors
            print(json.dumps({'case':name,'elapsed':round(time.monotonic()-start,3),'errors':errors,'result':'pass'}),flush=True)
            await context.close()
        finally:
            await browser.close()
asyncio.run(main())
