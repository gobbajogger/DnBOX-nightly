"""Run the checked-in footer journey against a staged product, with optional private source overlay."""
import argparse,asyncio,hashlib,importlib.util,json,sys,traceback
from pathlib import Path
from playwright.async_api import async_playwright,expect
ap=argparse.ArgumentParser()
ap.add_argument('site',type=Path)
ap.add_argument('result',type=Path)
ap.add_argument('--suite-root',type=Path,default=Path(__file__).parent/'engine-page')
ap.add_argument('--include-mix',action='store_true')
ap.add_argument('--overlay',action='store_true',help='serve candidate authored app.mjs and style.css on top of the base build')
a=ap.parse_args()
r=a.suite_root
suite=r/'tests/product-remote/drum-controls-browser.py'
spec=importlib.util.spec_from_file_location('drums',suite)
d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
d.core.SOURCE=a.site.resolve()
screens={s['path']:s for s in json.loads((r/'web/product-site/remote/components.json').read_bytes())['screens']}
sha=lambda b:hashlib.sha256(b).hexdigest()
async def main():
 a.result.mkdir(parents=True,exist_ok=True)
 rows=[];failures=[]
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(chromium_sandbox=True)
  try:
   for w,h in [(844,390),(640,390),(900,390),(390,844),(1024,640),(1440,900)]:
    ctx=await browser.new_context(viewport={'width':w,'height':h})
    row={'size':[w,h]}
    try:
     await ctx.route('**/*',d.core.serve)
     if a.overlay:
      async def overlay(route):
       p=r/'web/product-site/remote'/route.request.url.rsplit('/',1)[-1]
       await route.fulfill(status=200,content_type='text/javascript' if p.suffix=='.mjs' else 'text/css',body=p.read_bytes())
      for f in ('app.mjs','style.css'):await ctx.route('**/remote/'+f,overlay)
     page=await ctx.new_page();errors=[];page.on('pageerror',lambda exc:errors.append(str(exc)))
     await page.goto(d.core.ORIGIN+'/remote/')
     await page.locator('[data-engine="drum909"]').click()
     await page.locator('[data-view="sound"]').click()
     voice=page.locator('#sound-voice')
     await expect(voice).to_have_count(1);await expect(voice.locator('option')).to_have_count(11)
     chooser=page.get_by_role('combobox',name='Engine / page',exact=True)
     row={'size':[w,h],'selectedVoice':await voice.input_value()}
     if w in (844,640,900):
      await expect(chooser).to_be_visible()
      labels=await page.locator('.drum-sound-actions > *').evaluate_all("""es=>es.map(e=>{
       const r=e.getBoundingClientRect();return {name:e.getAttribute('aria-label')??e.textContent,x:r.x,y:r.y,w:r.width,h:r.height};
      })""")
      for i,g in enumerate(labels):
       assert g['w']>=40 and g['h']>=40 and 0<=g['x']<g['x']+g['w']<=w and 0<=g['y']<g['y']+g['h']<=h,(w,h,labels)
       if i:assert labels[i-1]['x']+labels[i-1]['w']<=g['x'],labels
      row['actions']=labels;row['panel']=await page.locator('[data-drum-sound-strip]').bounding_box()
      await page.screenshot(path=str(a.result/f'{w}x{h}-footer.png'))
      if w==844:
       await d.compact_voice(page,screens['current-state-and-reference/909-voice-00.svg'])
       await d.engine_page_footer(page,screens)
       row['kitVoiceDestinations']=22
     else:await expect(chooser).to_have_count(0)
     assert not errors,(w,h,errors);rows.append(row)
     (a.result/'geometry.json').write_text(json.dumps(rows,indent=2)+'\n')
     print('ENGINE_PAGE',w,h,'PASS',flush=True)
    except Exception as exc:
     row['failure']=str(exc);failures.append(['M089',w,h,str(exc)])
     if row not in rows:rows.append(row)
     (a.result/'geometry.json').write_text(json.dumps(rows,indent=2)+'\n')
     traceback.print_exc()
    finally:await ctx.close()
   if a.include_mix:
    f=r/'tests/product-remote/mix-family-browser.py'
    spec=importlib.util.spec_from_file_location('mix',f)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    m.core.SOURCE=a.site.resolve()
    for w,h in [(1440,900),(844,390),(390,844)]:
     ctx=await browser.new_context(viewport={'width':w,'height':h})
     try:
      await ctx.route('**/*',m.core.serve)
      page=await ctx.new_page();errors=[];page.on('pageerror',lambda err:errors.append(str(err)))
      await page.goto(m.core.ORIGIN+'/remote/')
      await page.locator('[data-view="mix"]').click()
      await m.check_delay_type(page)
      assert not errors,(w,h,errors)
      await page.screenshot(path=str(a.result/f'{w}x{h}-delay.png'))
      print('DELAY_TYPE',w,h,'PASS',flush=True)
     except Exception as exc:
      failures.append(['M057',w,h,str(exc)]);traceback.print_exc()
     finally:await ctx.close()
  finally:await browser.close()
 if failures:raise AssertionError(failures)
asyncio.run(main())
