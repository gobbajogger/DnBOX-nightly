"""Measure the native closed select including the browser's intrinsic arrow reservation."""
from pathlib import Path
import argparse,asyncio,importlib.util,json,io,math
from PIL import Image,ImageChops
from playwright.async_api import async_playwright,expect
ap=argparse.ArgumentParser();ap.add_argument('out',type=Path);ap.add_argument('--css',type=Path);args=ap.parse_args()
suite=Path('checkout/tests/product-remote/mix-family-browser.py')
spec=importlib.util.spec_from_file_location('mix',suite);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.core.SOURCE=Path('checkout/.output/product-site').resolve()
proc="""e=>{
 const s=getComputedStyle(e), rect=e.getBoundingClientRect(), borders=parseFloat(s.borderLeftWidth)+parseFloat(s.borderRightWidth);
 const padding=parseFloat(s.paddingLeft)+parseFloat(s.paddingRight),value=e.selectedOptions[0].textContent;
 const measure=document.createElement('canvas').getContext('2d');measure.font=s.font;const text=measure.measureText(value).width;
 // The difference between identical intrinsically-sized selects with native vs. appearance:none
 // measures the reservation of this browser's closed button (same computed font/border/padding).
 const clone=e.cloneNode(true);
 clone.style.cssText='position:fixed;left:-2000px;top:0;width:max-content;min-width:0;max-width:none;visibility:hidden;flex:none';
 e.parentNode.append(clone);
 const intrinsic=clone.getBoundingClientRect().width;
 clone.style.appearance='none';
 const plain=clone.getBoundingClientRect().width;clone.remove();
 const arrow=intrinsic-plain,space=rect.width-borders-padding-arrow;
 const coords=[[rect.width/2,rect.height/2],[8,8],[rect.width-8,8],[8,rect.height-8],[rect.width-8,rect.height-8]];
 return {value,x:rect.x,y:rect.y,w:rect.width,h:rect.height,leftPadding:s.paddingLeft,rightPadding:s.paddingRight,
     intrinsicWidth:intrinsic,intrinsicWithoutNativeArrow:plain,nativeArrowReservation:arrow,availableTextWidth:space,
     font:s.font,textAdvance:text,advanceFits:text<=space+.02,boxFits:rect.left>=0&&rect.right<=innerWidth&&rect.top>=0&&rect.bottom<=innerHeight,
     hit:coords.every(([x,y])=>document.elementFromPoint(rect.x+x,rect.y+y)===e)};
}"""
async def main():
 args.out.mkdir(parents=True,exist_ok=True);results=[]
 async with async_playwright() as pw:
  b=await pw.chromium.launch(chromium_sandbox=True)
  try:
   for w,h in [(844,390),(390,844),(1440,900)]:
    ctx=await b.new_context(viewport={'width':w,'height':h})
    try:
     await ctx.route('**/*',m.core.serve)
     if args.css:
      async def css(route):await route.fulfill(content_type='text/css',body=args.css.read_bytes())
      await ctx.route('**/remote/style.css',css)
     p=await ctx.new_page();errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
     await p.goto(m.core.ORIGIN+'/remote/')
     await p.locator('[data-view="mix"]').click();await m.mode(p,'fx')
     control=p.get_by_role('combobox',name='Delay type',exact=True)
     for val in ['1','0']:
      if await control.input_value()!=val:await control.select_option(val)
      await expect(control).to_have_value(val)
      # Playwright's ordinary scroll mechanism makes the live control fully visible.
      await control.scroll_into_view_if_needed()
      await control.focus()
      row=await control.evaluate(proc);row['viewport']=[w,h];results.append(row)
      assert row['boxFits'] and row['hit'] and row['w']>=44 and row['h']>=44,(w,h,row)
      await p.screenshot(path=str(args.out/f'{w}x{h}-{row["value"]}.png'))
      actual=await control.screenshot(path=str(args.out/f'{w}x{h}-{row["value"]}-field.png'))
      # Paint the identical native control at its original coordinates with extra
      # space. Compare the full visible text extent before the reference caret.
      style=await control.get_attribute('style')
      try:
       await control.evaluate('''e=>{
        const r=e.getBoundingClientRect();
        Object.assign(e.style,{position:'fixed',zIndex:999,left:r.left+'px',top:r.top+'px',width:'120px',
                               minWidth:'120px',maxWidth:'120px',height:r.height+'px',margin:'0'});
       }''')
       wide=await control.screenshot(path=str(args.out/f'{w}x{h}-{row["value"]}-reference.png'))
      finally:
       await control.evaluate('(e,s)=>s===null?e.removeAttribute("style"):e.setAttribute("style",s)',style)
      img,ref=[Image.open(io.BytesIO(b)).convert('RGB') for b in [actual,wide]]
      start=math.floor(float(row['leftPadding'].rstrip('px')))
      end=math.ceil(start+row['textAdvance'])+3
      region=(start,6,min(end,img.width),min(img.height,ref.height)-6)
      diff=ImageChops.difference(img.crop(region),ref.crop(region))
      row['textCrop']=region;row['wideReferenceTextMatch']=not diff.getbbox()
      row['differentTextPixels']=sum(any(channel>0 for channel in pixel) for pixel in diff.getdata())
      print('MEASURE',json.dumps(row),flush=True)
     assert not errors,errors
    finally:await ctx.close()
  finally:await b.close()
 (args.out/'metrics.json').write_text(json.dumps(results,indent=2)+'\n')
asyncio.run(main())
