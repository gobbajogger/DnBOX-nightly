import argparse
from contextlib import ExitStack
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from threading import Thread
import hashlib, importlib.util, io, json, sys, time
from PIL import Image, ImageChops
from playwright.sync_api import sync_playwright
parser=argparse.ArgumentParser()
parser.add_argument('checkout',type=Path)
parser.add_argument('receipt_directory',type=Path)
args=parser.parse_args()
base=args.checkout.resolve()
out=args.receipt_directory.resolve();out.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(base/'tests/visual'))
spec=importlib.util.spec_from_file_location('breaks_candidate',base/'tests/visual/visual_gate.py');gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
records=[]
class Silent(SimpleHTTPRequestHandler):
    def log_message(self,*args): pass
with ThreadingHTTPServer(('127.0.0.1',0),partial(Silent,directory=str(base/'web'))) as server:
    worker=Thread(target=server.serve_forever,daemon=True);worker.start()
    url=f'http://127.0.0.1:{server.server_address[1]}/product-site/breaks/index.html'
    try:
      with sync_playwright() as pw, pw.chromium.launch(chromium_sandbox=True,args=['--font-render-hinting=none','--disable-lcd-text','--force-color-profile=srgb']) as browser:
        for case,blocked,mutation,expected in [
          ('original',None,None,None),
          ('no site rules','**/site.css',None,'site.css did not load'),
          ('no tool rules','**/tool-theme.css',None,'tool-theme.css did not load'),
          ('missing bold face','**/BarlowSemiCondensed-Bold.ttf',None,'Barlow 700 did not load'),
          ('missing regular face','**/BarlowSemiCondensed-Medium.ttf',None,'Barlow normal did not load'),
          ('no module',None,"delete window.sampleWorkspace",'sample workspace did not initialize'),
          ('wrong slot mode',None,"document.querySelector('#list .empty').textContent='Reading…'",'disconnected slot list is missing'),
          ('write enabled',None,"document.querySelector('#send').disabled=false",'initial device actions are not disabled')]:
          with browser.new_context(viewport={'width':1440,'height':900},device_scale_factor=1,reduced_motion='reduce',locale='en-US',timezone_id='UTC') as ctx:
            ctx.add_init_script(gate.FREEZE_JS);page=ctx.new_page();errors=[];responses=[]
            page.on('pageerror',lambda error:errors.append(str(error)))
            page.on('response',lambda r:responses.append([r.url.replace(url.split('/product-site/')[0],''),r.status]))
            if blocked:page.route(blocked,lambda r:r.abort())
            page.goto(url);page.add_style_tag(content=gate.FREEZE_CSS)
            if mutation:page.evaluate(mutation)
            start=time.monotonic()
            try:gate.wait_for_breaks_capture(page)
            except Exception as e:
              if expected is None or expected not in str(e):raise
              observed=str(e).splitlines()[0]
            else:
              assert expected is None,case
              page.wait_for_timeout(250)
              shot=gate.capture_full_page(page,'breaks/index.html','site-breaks-1440x900');(out/'site-breaks.png').write_bytes(shot)
              with Image.open(io.BytesIO(shot)) as current,Image.open(Path(__file__).with_name('previous-capture.png')) as original:
                assert current.size==original.size;diff=ImageChops.difference(current.convert('RGB'),original.convert('RGB'));assert not diff.getbbox(),diff.getbbox()
              assert not errors,errors;assert len(responses)==5 and all(r[1]==200 for r in responses),responses
              observed='capture pixel-identical to previous original: '+hashlib.sha256(shot).hexdigest()
            records.append(dict(case=case,result=observed,elapsed=round(time.monotonic()-start,3),responses=responses,pageErrors=errors));print(case,observed,flush=True)
    finally:server.shutdown();worker.join()
(out/'positive-negative.json').write_text(json.dumps(records,indent=2,ensure_ascii=False)+'\n')
