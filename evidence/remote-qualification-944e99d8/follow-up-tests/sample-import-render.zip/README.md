# Sample-import page capture on Chromium 151

The original visual run on `59d83425` produced the included 1440 × 1175 PNG. It is a diagnostic capture, not an approved design baseline. The revised full-page check produced the exact same PNG bytes. Each of seven independent invalid states was then tested in a fresh sandboxed Chromium context. See `positive-negative.json` for all requests and outcomes.

Run `python prove-breaks.py /path/to/nightly /path/to/receipts` with the repository's bundled Playwright, fonts and normally sandboxed Chromium. The proof serves the checkout's actual web files on loopback, applies the visual gate's own frozen clock and raster flags, then calls the production capture checker. The failure cases block the source stylesheet, theme stylesheet, each of two fonts, the initialized workspace, the disconnected slot state and the disabled Send action. The local server never opens MIDI. The source module remains unchanged.

The first experimental check already rejected an aborted stylesheet, but Chromium reported an unreadable CSS rule list as a SecurityError. The published check identifies which required stylesheet failed.
