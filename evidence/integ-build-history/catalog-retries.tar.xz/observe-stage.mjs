import fs from 'node:fs';
import { performance } from 'node:perf_hooks';
import { syncBuiltinESMExports } from 'node:module';
if (process.argv[1]?.endsWith('/render-qualified-nightly.mjs')) {
  const start = performance.now();
  let reads = 0;
  const log = phase => fs.appendFileSync(process.env.CATALOG_TRACE_PATH, JSON.stringify({pid:process.pid, phase, reads, elapsed_ms:Math.round(performance.now()-start)})+'\n');
  log('child entry');
  for (const method of ['readFileSync','cpSync','renameSync','mkdtempSync']) {
    const original = fs[method];
    fs[method] = function(...args) {
      if (method === 'readFileSync') {
        reads++;
        if (reads===1 || reads % 20===0) log('reading source '+reads);
        return original.apply(this,args);
      }
      log('start '+method); try { return original.apply(this,args); } finally { log('finish '+method); }
    };
  }
  syncBuiltinESMExports();
  process.on('exit', () => log('exit'));
}
