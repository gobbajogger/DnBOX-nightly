import childProcess from 'node:child_process';
import { syncBuiltinESMExports } from 'node:module';
const original = childProcess.spawnSync;
childProcess.spawnSync = function(command, args, options) {
  const started = performance.now();
  const result = original.apply(this, arguments);
  if (args?.some(s => s.endsWith('render-qualified-nightly.mjs'))) {
    process.stderr.write(JSON.stringify({command: 'render-qualified-nightly.mjs', timeout: options.timeout, elapsed_ms: Math.round(performance.now() - started), status: result.status, signal: result.signal, error: result.error?.code ?? null}) + '\n');
  }
  return result;
};
syncBuiltinESMExports();
