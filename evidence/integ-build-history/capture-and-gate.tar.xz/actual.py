from functools import partial
from http.server import ThreadingHTTPServer
from io import BytesIO
from pathlib import Path
from threading import Thread
import hashlib, json, subprocess, sys, time
from PIL import Image
from playwright.sync_api import sync_playwright

root=Path.cwd()
sys.path.insert(0,str(root/'tests/visual'))
import full_page_capture as capture
from serve_source import SiteSourceHandler
from visual_gate import FREEZE_CSS, FREEZE_JS
out_path=Path('../logs/history-real-browser.json')
trace={'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
       'viewport':[390,844], 'timeout_seconds':30, 'browser_sandbox':True,
       'requests_failed':[], 'http_errors':[], 'page_errors':[], 'measurements':[]}
class TimedPage:
    def __init__(self,page):self.page=page
    def evaluate(self,expr):
        result=self.page.evaluate(expr)
        trace['measurements'].append({'evaluate_geometry':result})
        return result
    def screenshot(self,**kwargs):
        row={'screenshot':kwargs}
        trace['measurements'].append(row)
        before=time.monotonic()
        try:
            png=self.page.screenshot(**kwargs)
            row['bytes']=len(png)
            return png
        finally:row['elapsed_s']=round(time.monotonic()-before,6)
try:
    with sync_playwright() as pw:
        executable=Path(pw.chromium.executable_path)
        args=['--font-render-hinting=none','--disable-lcd-text','--force-color-profile=srgb']
        options={'chromium_sandbox':True,'args':args}
        trace['registered_executable']=str(executable)
        trace['registered_executable_present']=executable.exists()
        if not executable.exists():
            options['executable_path']='/usr/bin/chromium'
            trace['run_kind']='system Chromium diagnostic'
            trace['version']=subprocess.check_output(['/usr/bin/chromium','--version'],text=True).strip()
        else:trace['run_kind']='Playwright bundled Chromium'
        with pw.chromium.launch(**options) as browser, browser.new_context(viewport={'width':390,'height':844},device_scale_factor=1,has_touch=True,reduced_motion='reduce',locale='en-US',timezone_id='UTC') as context:
            trace['browser_version']=browser.version
            context.add_init_script(FREEZE_JS)
            with ThreadingHTTPServer(('127.0.0.1',0),partial(SiteSourceHandler,directory=root/'web')) as server:
                thread=Thread(target=server.serve_forever,daemon=True);thread.start()
                try:
                    p=context.new_page()
                    p.on('pageerror',lambda err:trace['page_errors'].append(str(err)))
                    p.on('response',lambda res:trace['http_errors'].append([res.status,res.url]) if res.status>=400 else None)
                    p.on('requestfailed',lambda req:trace['requests_failed'].append([req.url,req.failure]))
                    p.goto(f'http://127.0.0.1:{server.server_port}/product-site/builds/index.html')
                    p.add_style_tag(content=FREEZE_CSS)
                    p.evaluate('document.fonts.ready');p.wait_for_load_state('networkidle');p.wait_for_timeout(250)
                    trace['articles']=p.locator('article').count()
                    assert trace['articles']==198 and not any((trace['requests_failed'],trace['http_errors'],trace['page_errors'])),trace
                    start=time.monotonic()
                    try:data=capture.capture_full_page(TimedPage(p),'builds/index.html','site-builds-390x844')
                    finally:trace['capture_elapsed_s']=round(time.monotonic()-start,6)
                    trace['png_sha256']=hashlib.sha256(data).hexdigest();trace['png_bytes']=len(data)
                    with Image.open(BytesIO(data)) as im:trace['size']=im.size; im.load()
                    (root/'.cache/history-capture/proposed-phone.png').write_bytes(data)
                    trace['complete']=True
                finally:server.shutdown();thread.join()
except Exception as exc:
    trace['complete']=False;trace['reason']=str(exc)
finally:
    out_path.write_text(json.dumps(trace,indent=2)+'\n')
print(json.dumps(trace))
sys.exit(0 if trace.get('complete') else 1)
