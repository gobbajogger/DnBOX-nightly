import asyncio, importlib.util, json, re
from pathlib import Path
from playwright.async_api import async_playwright
root=Path('checkout').resolve()
out=Path('qawork/drum-fit/before').resolve()
spec=importlib.util.spec_from_file_location('suite',root/'tests/product-remote/drum-controls-browser.py')
drum=importlib.util.module_from_spec(spec); spec.loader.exec_module(drum)
core=drum.core; core.SOURCE=root/'.output/product-site'
probe="""() => {
 const inspect = e => {const r=e.getBoundingClientRect(), s=getComputedStyle(e);const {top,left,bottom,right,width,height}=r;const at=document.elementFromPoint(r.x+width/2,r.y+height/2);return {id:e.id,tag:e.tagName,label:e.getAttribute('aria-label')??e.textContent.trim(),disabled:e.disabled,value:e.value,flex:s.flex,position:s.position,top,left,bottom,right,width,height,centerHit:!!at&&(at===e||e.contains(at)),visible:width>0&&height>0,focus:document.activeElement===e,fullWithin:top>=0&&bottom<=innerHeight&&left>=0&&right<=innerWidth};};
 const view=document.querySelector('#other-view'),inspector=document.querySelector('#parameter-inspector'),strip=document.querySelector('[data-drum-sound-strip]');
 return {innerHeight,scrollTop:view.scrollTop,scrollHeight:view.scrollHeight,clientHeight:view.clientHeight,strip:inspect(strip),inspector:inspect(inspector),inspectorText:inspector.textContent.trim(),active:document.activeElement?.id,inputs:[...inspector.querySelectorAll('button,input,select')].map(inspect),buttons:[...view.querySelectorAll('[data-drum-decrement], [data-drum-increment], .drum-sound-actions button')].map(inspect)};
}"""
async def main():
 await asyncio.to_thread(core.preload_product,core.SOURCE)
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(chromium_sandbox=True)
  try:
   ctx=await browser.new_context(viewport={'width':844,'height':390})
   await ctx.route('**/*',core.serve); page=await ctx.new_page()
   await page.add_init_script('window.midiCalls=0;navigator.requestMIDIAccess=()=>{midiCalls++;throw Error("No devices")}')
   await page.goto(core.ORIGIN+'/remote/')
   await page.locator('[data-engine="drum909"]').click(); await page.locator('[data-view="sound"]').click()
   voice=page.locator('#sound-voice'); await voice.select_option('0')
   async def state(name):
    s=await page.evaluate(probe); (out/(name+'.json')).write_text(json.dumps(s,indent=2)+'\n')
    print(name,'inspector',s['inspectorText'],[(x['id'],x['top'],x['bottom'],x['width'],x['height'],x['centerHit'],x['fullWithin'],x.get('disabled')) for x in s['inputs']], 'scroll',s['scrollTop'],s['scrollHeight'],s['clientHeight'],'stripH',s['strip']['height'],'buttons',len(s['buttons']),all(x['centerHit'] and x['fullWithin'] for x in s['buttons']),flush=True)
   await state('untouched')
   await drum.kick_depth_dependencies(page); await state('after-three-undo')
   field=page.locator('#parameter-value');await field.click();await state('field-native-pointer')
   await page.mouse.move(720,323);await page.mouse.wheel(0,340)
   await page.wait_for_timeout(175);await state('wheel-panel-bottom')
   await field.press('Tab');await state('keyboard-next')
   await voice.select_option('1');await voice.select_option('0');await state('reselect-voice')
   await page.screenshot(path=str(out/'844x390-after-reselect.png'))
   await page.get_by_role('button',name='Open original',exact=True).press('Enter')
   await page.locator('.source-scene svg').screenshot(path=str(out/'844x390-open-original-909bd.png'))
   await ctx.close()
  finally: await browser.close()
asyncio.run(main())
