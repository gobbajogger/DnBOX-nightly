import asyncio, importlib.util, json, sys, subprocess
from pathlib import Path
from playwright.async_api import async_playwright
root=Path(sys.argv[1]).resolve()
out=Path(sys.argv[2]).resolve()
out.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('drum',root/'tests/product-remote/drum-controls-browser.py')
drum=importlib.util.module_from_spec(spec)
spec.loader.exec_module(drum)
core=drum.core
core.SOURCE=root/'.output/product-site'
measure="""() => {
  const info = e => {if(!e)return null;const b=e.getBoundingClientRect(),s=getComputedStyle(e);return {tag:e.tagName,id:e.id,cls:e.className?.baseVal??e.className,hidden:e.hidden,y:b.y,h:b.height,w:b.width,bottom:b.bottom,display:s.display,flex:s.flex,flexdir:s.flexDirection,alignItems:s.alignItems,alignContent:s.alignContent,height:s.height,minHeight:s.minHeight,maxHeight:s.maxHeight,gridTemplateRows:s.gridTemplateRows,overflowY:s.overflowY,scrollHeight:e.scrollHeight,clientHeight:e.clientHeight};};
  const strip=document.querySelector('[data-drum-sound-strip]');
  const chain=[]; for(let e=strip;e;e=e.parentElement)chain.push(info(e));
  let view=document.querySelector('#other-view');
  return {view:info(view),viewport:[innerWidth,innerHeight],layout:{...document.querySelector('#workspace-main').dataset},visibleChildren:[...view.children].filter(e=>e.getBoundingClientRect().height).map(info),chain,siblings:[...document.querySelector('#workspace-main').children].filter(e=>e.getBoundingClientRect().height).map(info),actions:[...document.querySelectorAll('[data-drum-decrement]')].slice(0,2).map(info),href:location.href,media:matchMedia('(orientation:landscape) and (max-height:500px)').matches};
}"""
async def main():
 await asyncio.to_thread(core.preload_product,core.SOURCE)
 print('HEAD',subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),flush=True)
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(chromium_sandbox=True)
  try:
   for width,height in [(844,390),(390,844),(1440,900),(1024,640)]:
    context=await browser.new_context(viewport={'width':width,'height':height})
    await context.route('**/*',core.serve); page=await context.new_page()
    await page.add_init_script('window.midiCalls=0;navigator.requestMIDIAccess=()=>{midiCalls++;throw Error("No devices")}')
    await page.goto(core.ORIGIN+'/remote/')
    await page.locator('[data-engine="drum909"]').click()
    await page.locator('[data-view="sound"]').click()
    await page.locator('#sound-voice').select_option('0')
    for name in ['entered','edited-then-undone']:
     if name=='edited-then-undone':
      if width!=844: continue
      await drum.kick_depth_dependencies(page)
     v=await page.evaluate(measure)
     label=f'{width}x{height}-{name}'
     (out/f'{label}.json').write_text(json.dumps(v,indent=2)+'\n')
     await page.screenshot(path=str(out/f'{label}.png'))
     print(label,json.dumps({'layout':v['layout'],'chain':[(e['tag'],e['id'],e['cls'],e['y'],e['h'],e['display'],e['flex']) for e in v['chain']],'children':[(e['tag'],e['id'],e['cls'],e['y'],e['h']) for e in v['visibleChildren']],'actions':[(e['y'], e['h']) for e in v['actions']]}),flush=True)
    await context.close()
  finally:
   await browser.close()
asyncio.run(main())
