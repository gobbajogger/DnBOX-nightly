# Independent 909 kick Sound geometry review

The reviewed Remote is commit `495159ad096fe829db2141b237ac24b921bb09fa`. The normal Sound route ran in bundled Chromium 151.0.7922.34. Each original screenshot has its CSS viewport dimensions in the filename. The three larger or portrait views show the source editor. The 844×390 route shows the compact strip.

| 844×390 state | Strip height | Adjustment buttons start | Footer bottom | Inspector |
| --- | ---: | ---: | ---: | --- |
| Select 909, Sound, BD | 208 | 292 | 390 | Hidden |
| Edit Tune, Depth and Pitch, then Undo all three | 127.28125 | 211.28125 | 309.28125 | Selected Pitch, raw 45, +0.1st |
| Select voice 1 and return to BD | 208 | 292 | 390 | Hidden |

The pristine strip meets the page 18 thresholds for height and footer placement. After the three Undo operations, the selected Pitch field intentionally stays open. It occupies the region beneath the footer. All 12 step buttons and three footer actions remained wholly visible and center-hittable, with a minimum target of 48×44. The selected 88×40 numeric field accepted pointer focus. Its 53×40 Undo control was disabled with the original values restored. Both controls lay within the viewport at y340.28125 to 380.28125. Ordinary wheel input moved the panel nine pixels to expose the bottom edge of its padding. The inspector contains the field and Undo. Changing voices through the normal selector restores the untouched state.

The committed browser sequence calls the three-edit helper immediately before checking page 18 geometry. The original gate consequently applied pristine layout thresholds to the open-inspector state. Unmodified expected geometry and the same post-edit usability can be checked independently.

The genuine stock 240×240 909 kick frame comes from firmware `61827a714ca7b240c01a55ed347b5fd7b847c7c2`, state `view-01-part-00-voice-00-page-00`. Its 57,600 RGB pixels match SHA-256 `db9dc5645dde838ecd36545c1d2f6272ff4dc1e08aa466ea887a130c746e9584` in the repository’s independent native oracle. Stock and Remote show Tune 13ms, Attack 10%, Depth 0%, Pitch +0.1st, Decay 1.0s and kit level 100%. Stock groups four values across the top with AMP and KIT below. The owner page 18 drawing places all six in one row, with fork-shaped Tune and Pitch marks. The compact Remote follows the owner arrangement. The “Open original” capture separately records the product’s reconstructed source editor.

The gate raw output, storage sampler, all four original-size screen images, normal route state JSON and native proof are included. The full gate also failed its independent catalog positive control against shared filesystem exhaustion. The original, terminal raw gate log is 119,136 bytes with SHA-256 `3a88f517f2c866080f1ac335047ff7763e45aafb1c3542f22c01b311d10d8e18`.

## Four normal entry views

| Viewport | Mounted 909 Sound body | Body y | Body height |
| --- | --- | ---: | ---: |
| 1440×900 | Original source scene | 313 | 440 |
| 390×844 | Original source scene | 341 | 336 |
| 844×390 | Compact six-control row | 132 | 208 |
| 1024×640 | Original source scene | 313 | 440 |

The normal-size owner comparison comes from owner drawing page 18 in PDF SHA-256 `db826c9cbeb84971f2d030c847043a21749ad4172e30739773494df0c9acca17`. This reviewer found the fixture state ordering issue described above. Both independent routes passed the page-state criteria applicable to them, and the inspected controls remained reachable. Test repair and its complete three-viewport result belong to the successor revision. This independent review covers only the 909 kick Sound states exercised. Whole Remote, website and firmware joint owner review, the 17:00 glyph decision and owner signatures remain open.
