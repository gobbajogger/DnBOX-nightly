# Full-page original manual capture

The source under test is DnBOX-nightly f868dea604256d29fef6024326b0c208cd86f3fe plus the candidate capture and contract files. The HTML, 15 image elements, shared styles, bundled fonts and browser configuration are the input to every trial. `input-objects.json` records Git object identities and the Chromium executable digest. The historical portrait run uses the published stylesheet at c062a3090b1fa8620b707ed50c5757586ebfaa6b. The original page route is `/product-site/manual/original/index.html`.

## Measured contracts

`report.json` gives the initial document extents, tested and changed pixel counts, RGB hashes, peak memory, timings, and desktop repeats. Each qualified viewport has a fresh whole-page Chromium PNG, the preceding 1,024-row method, and the candidate bounded method on separate sandboxed Chromium processes. `proof/qual-index.json` identifies the selected measurements. `proof/qual-comparisons.jsonl` contains the independent decodes, including the final row and both rows bordering each join. Current mobile CSS removed the old overflow. The additional historical portrait comparison in `proof/historical-comparison.json` uses the archived c062 CSS and the same manual and fonts. Its 476×36,145 extent exercises all 3,108,470 pixels in the 86-column overhang. The other three current RGB hashes equal the original values. Together these verify all 95,885,312 historical native pixels. `proof/*row-sha256.bin.gz` contains a pair of binary SHA-256 digests for each RGB scanline, ordered top to bottom. In each pair the first 32 bytes identify the native row and the next 32 identify the bounded row. Equal rows compress together. Full PNGs are transient and never installed as references.

`proof/*.json` records the actual clock times and clip rectangles, image and font state, starting and ending viewport/DPR/scroll, output PNG CRC verification, memory samples, and kernel OOM count. Every successfully sampled process belongs to the Python, Playwright, or Chromium process tree. PSS avoids counting shared mappings multiple times. Results are sampled peaks, and individual renderer/GPU figures are RSS. The number of samples depends on capture latency. `historical-four-size.json` is the earlier checked-in native/1,024-row control. `d7da-manual-profile.log` and `f868-original-full-gate-failure.log` preserve the prior 29.103-second capture and the later deadline failure. The comparison report retains pre-capture host storage errors and timed failures separately. The whole capture budget is 30 seconds in both bounded implementations.

## Reproduction

Start with a checkout containing the candidate in `tests/visual/manual_capture.py` and its `test_visual_gate.py`. Install the checkout's visual test dependencies and the matching Chromium revision. The reference runner uses Python with Playwright, Pillow, NumPy, and psutil. Extract this directory to an empty workspace. Set `DNBOX_MANUAL_CHECKOUT` to that checkout, `PLAYWRIGHT_BROWSERS_PATH` to the browser install and `TMPDIR` to an existing writable location. Loopback HTTP must be reachable. Retain the original helper in the included `baseline.py`.

The following example creates a fresh native pair for the largest viewport. Use 1024×640, 844×390, and 390×844 for the other dimensions.

```sh
python live.py native 1440 900 fresh
python live.py candidate 1440 900 fresh
python compare.py fresh-native-1440x900 fresh-candidate-1440x900
python live.py baseline 1440 900 fresh
python compare.py fresh-native-1440x900 fresh-baseline-1440x900
```

To reproduce the old portrait geometry, copy the checkout to a separate directory and restore `web/product-site/site.css` from c062a3090b1fa8620b707ed50c5757586ebfaa6b. Set `DNBOX_MANUAL_CHECKOUT` to this separate checkout, `DNBOX_MANUAL_INPUT_COMMIT` to the historical commit, and `DNBOX_MANUAL_INPUT_OBJECTS` to the included historical input JSON. Repeat native, candidate and compare at 390×844. The original manual subtree and both font blobs are identical to those in f868.

In the checkout, the capture and comparator contracts run with `python -m unittest discover -s tests/visual -p test_visual_gate.py` and `python -m unittest discover -s tests/visual -p test_capture_actual.py`. Reproducing one site capture requires no change to default test selection or approved images.

`offline-cpu.jsonl` records synthetic full-document PNG encoding tests using real illustrated manual source images. `native-tile-packing.json` records the shuffled native-tile experiment in four rounds. The end-to-end Chromium results in `report.json` include the true native capture, decoding and encoding costs.
