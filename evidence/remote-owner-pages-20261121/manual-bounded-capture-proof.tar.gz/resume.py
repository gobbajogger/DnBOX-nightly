import json, shutil, subprocess, sys, time
from pathlib import Path
base=Path(__file__).resolve().parent
out=base/'proof'
index={}
def capture(w,h,mode,tag,existing=True):
    if existing:
        for png in sorted(out.glob(f'*-{mode}-{w}x{h}.png')):
            stem=png.stem
            if json.loads(png.with_suffix('.json').read_text())['ok']:
                return stem
    for attempt in range(30):
        trial=f'{tag}{attempt+1}'
        stem=f'{trial}-{mode}-{w}x{h}'
        print('start',stem,'free',shutil.disk_usage(base).free,flush=True)
        subprocess.run([sys.executable,str(base/'live.py'),mode,str(w),str(h),trial])
        r=json.loads((out/(stem+'.json')).read_text())
        if r['ok']: return stem
        if 'ENOSPC' in str(r) and 'seconds' not in r:
            time.sleep(3); continue
        if mode=='baseline': return None
        raise RuntimeError(stem)
    raise RuntimeError('Repeated Chromium tempfile ENOSPC '+stem)
def compare(left,right):
    p=subprocess.run([sys.executable,str(base/'compare.py'),left,right],capture_output=True,text=True)
    print(p.stdout,p.stderr,flush=True); p.check_returncode()
    with (out/'qual-comparisons.jsonl').open('a') as f:f.write(p.stdout)
for w,h in [(1440,900),(1024,640),(844,390),(390,844)]:
    key=f'{w}x{h}'
    native=capture(w,h,'native','q')
    entry=index[key]={'native':native}
    for mode in ['candidate','baseline']:
        other=capture(w,h,mode,'q')
        entry[mode]=other
        if other: compare(native,other)
    if w==1440:
        for mode in ['baseline','candidate']:
            other=capture(w,h,mode,'repeat',False)
            entry['repeat-'+mode]=other
            if other:compare(native,other)
    (out/'qual-index.json').write_text(json.dumps(index,indent=2)+'\n')
    for stem in entry.values():
        if stem:(out/(stem+'.png')).unlink(missing_ok=True)
