"""Summarize the matched, successful runs and retain separately labelled launch failures."""
import json
from pathlib import Path

base=Path(__file__).resolve().parent
proof=base/'proof'
historical=json.loads((base/'historical-four-size.json').read_text())
history={tuple(r['viewport']):r for r in historical['viewportResults']}
index=json.loads((proof/'qual-index.json').read_text())
comparisons=[json.loads(line) for line in (proof/'qual-comparisons.jsonl').read_text().splitlines()]
results=[]
def summary(q):
    data=q['peak']
    pss=data['allPssKiB']
    return dict(wallSeconds=q['seconds'],peakTreePssKiB=pss,peakChromiumPssKiB=data['browserPssKiB'],
        peakSingleRendererRssKiB=data['rendererMaxRssKiB'],peakSingleGpuRssKiB=data['gpuMaxRssKiB'],
        nativeCalls=len(q['shots']),nativeCaptureSeconds=round(sum(s['seconds'] for s in q['shots']),4),
        samples=q['samples'],pssReadDenied=sum(len(s['pssDenied']) for s in q['memorySamples']),
        kernelOomKillDelta=q['oom'][1]-q['oom'][0],pngBytes=q['pngBytes'])
for viewport, trials in index.items():
    info={key:json.loads((proof/(stem+'.json')).read_text()) for key,stem in trials.items() if stem}
    q=info['candidate']
    v=tuple(q['viewport'])
    hist=history[v]
    comp=next(a for a in comparisons if a['candidate']==trials['candidate'])
    runs={mode:summary(case) for mode,case in info.items()}
    budgets=[round(c['wallSeconds'],4) for k,c in runs.items() if 'candidate' in k]
    def delta(x,y):return round(100*(x/y-1),2)
    c=runs['candidate'];n=runs['native'];b=runs.get('baseline')
    results.append(dict(viewport=v,extent=q['imageSize'],captures=runs,nativePixels=comp['pixels'],changedPixels=comp['changed'],
        boundaryDifferences=comp['seams'],finalRowDifferences=comp['lastRowDifferent'],overhangPixels=comp['overhangPixels'],
        overhangDifferences=comp['overhangDifferent'],rgbSha256=comp['actualRGB'],historicalRgbSha256=hist['decodedRgbSha256'],
        historicalBoundedPssKiB=hist['observedResources']['pssKiB'],historicalBoundedSeconds=hist['seconds'],
        originalNativePssKiB=historical['native1440']['observedResources']['pssKiB'] if v==(1440,900) else None,
        treePssPercentChangeVsNative=delta(c['peakTreePssKiB'],n['peakTreePssKiB']),
        treePssPercentChangeVsPriorBounded=delta(c['peakTreePssKiB'],b['peakTreePssKiB']) if b else None,
        wallPercentChangeVsPriorBounded=delta(c['wallSeconds'],b['wallSeconds']) if b else None,
        minimumMeasuredDeadlineMargin=round(30-max(budgets),4)))
failed={}
for path in sorted(proof.glob('*.json')):
    if path.name=='qual-index.json':continue
    j=json.loads(path.read_text())
    if 'ok' in j and not j['ok']:failed[path.name]=dict(captureStarted='seconds' in j,error=j['error'].strip().splitlines()[-1])
report=dict(source='f868dea604256d29fef6024326b0c208cd86f3fe',deadlineSeconds=30,
    sampling='Python, Playwright driver and all Chromium descendants. Peak is the maximum summed PSS among samples. Nominal 200 ms wait between reads; process-tree sampling is not an allocator high-water mark.',
    successes=results,preCaptureOrRuntimeFailures=failed,
    totalCandidatePixels=sum(r['nativePixels'] for r in results),totalDifferentPixels=sum(r['changedPixels'] for r in results),
    verifiedViewportCount=len(results))
supplement=json.loads((proof/'historical-comparison.json').read_text())
old_portrait=history[390,844]
unchanged=[r for r in results if r['rgbSha256']==r['historicalRgbSha256']]
assert len(unchanged)==3
assert supplement['actualRGB']==old_portrait['decodedRgbSha256']
assert supplement['changed']==0 and supplement['overhangColumns']==86 and supplement['overhangPixels']==86*36145
report['historicalExtentCoverage']=dict(historicalPixels=sum(r['nativePixels'] for r in unchanged)+supplement['pixels'],
    changed=0,currentRgbEqualOnThreeViewports=[r['viewport'] for r in unchanged],
    portrait= {k:supplement[k] for k in ['viewport','dimensions','pixels','changed','overhangColumns','overhangPixels','overhangDifferent','seams','lastRowDifferent','expectedRGB','actualRGB']},
    originalCss='3a7f051ee13f5a5619b6e1f07cf97e68b99ea083',
    currentCss='74b90cf9b79eb85b6b4fe52d60c7c0d4c00970dd',
    historicalPortraitRuns={k:summary(json.loads((proof/(supplement[k]+'.json')).read_text())) for k in ('reference','candidate')})
assert report['historicalExtentCoverage']['historicalPixels']==historical['allPixelsCompared']
print(json.dumps(report,indent=2))
