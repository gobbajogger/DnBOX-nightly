"""Decode in strips and compare every RGB pixel and capture boundary."""
import gzip,json,hashlib,sys
from pathlib import Path
import numpy as np
from PIL import Image
base=Path(__file__).resolve().parent/'proof';left,right=sys.argv[1:3]
a=json.loads((base/(left+'.json')).read_text());b=json.loads((base/(right+'.json')).read_text())
assert a['ok'] and b['ok']
assert a['viewport']==b['viewport'] and a['imageSize']==b['imageSize']
assert a['before']['viewport']==b['before']['viewport'] and a['before']['fonts']==b['before']['fonts']
def images(report):
 return [(url.split('/product-site/')[-1],done,w,h) for url,done,w,h in report['before']['images']]
assert images(a)==images(b)
with Image.open(base/(left+'.png')) as x, Image.open(base/(right+'.png')) as y:
 assert x.mode==y.mode=='RGB' and x.size==y.size
 width,height=x.size;logical=a['viewport'][0]
 seams=[s['clip']['y'] for s in b['shots'] if s['clip'] and s['clip']['y']]
 row_hashes=bytearray();ds={boundary:0 for boundary in seams};diff=overhang=final=0;ha=hashlib.sha256();hb=hashlib.sha256()
 for first in range(0,height,96):
  last=min(height,first+96)
  xa=np.asarray(x.crop((0,first,width,last)));ya=np.asarray(y.crop((0,first,width,last)))
  ha.update(xa);hb.update(ya)
  for native_row,trial_row in zip(xa,ya):
   row_hashes.extend(hashlib.sha256(native_row).digest())
   row_hashes.extend(hashlib.sha256(trial_row).digest())
  mask=(xa!=ya).any(axis=2)
  diff+=int(mask.sum());overhang+=int(mask[:,logical:].sum())
  for boundary in seams:
   lo=max(first,boundary-1); hi=min(last,boundary+1)
   if hi>lo:ds[boundary]+=int(mask[lo-first:hi-first].sum())
  if last==height:final=int(mask[-1].sum())
 out=dict(reference=left,candidate=right,viewport=a['viewport'],dimensions=[width,height],pixels=width*height,changed=diff,seams=ds,lastRowDifferent=final,overhangColumns=max(0,width-logical),overhangPixels=max(0,width-logical)*height,overhangDifferent=overhang,expectedRGB=ha.hexdigest(),actualRGB=hb.hexdigest(),sameSourceState=True)
 if b['mode']=='candidate':
  row_file=base/(right+'-native-and-candidate-row-sha256.bin.gz')
  row_file.write_bytes(gzip.compress(row_hashes,mtime=0))
  out['pairedScanlineHashes']={'file':row_file.name,'rowCount':height,'format':'32 native SHA256 bytes then 32 candidate SHA256 bytes for every RGB row in top-to-bottom order','sha256':hashlib.sha256(row_file.read_bytes()).hexdigest()}
 print(json.dumps(out),flush=True)
 assert diff==0
