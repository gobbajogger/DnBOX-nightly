"""Collect a matched, sandboxed native or banded original-manual capture."""
import contextlib,functools,hashlib,http.server,importlib.util,io,json,os,sys,threading,time,traceback
from pathlib import Path
from importlib.metadata import version
import psutil
from PIL import Image
from playwright.sync_api import sync_playwright

BASE=Path(__file__).resolve().parent
SOURCE=Path(os.environ.get('DNBOX_MANUAL_CHECKOUT', BASE/'repo')).resolve()
sys.path.insert(0,str(SOURCE/'tests/visual'))
import visual_gate as gate
import manual_capture as candidate
spec=importlib.util.spec_from_file_location('old_manual',BASE/'baseline.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
MODE=sys.argv[1];W,H=map(int,sys.argv[2:4]);run_id=sys.argv[4]
out=BASE/'proof';stem=f'{run_id}-{MODE}-{W}x{H}'
root=psutil.Process()
class Observe:
 def __init__(self,page):
  self.page=page;self.shots=[];self.start=None
 def __getattr__(self,k):return getattr(self.page,k)
 def screenshot(self,**kwargs):
  t=time.monotonic()
  try:return self.page.screenshot(**kwargs)
  finally:self.shots.append(dict(clip=kwargs.get('clip'),timeout=kwargs.get('timeout'),at=round(t-self.start,4),seconds=round(time.monotonic()-t,4)))

def oom():
 try:return int(next(line for line in Path('/proc/vmstat').read_text().splitlines() if line.startswith('oom_kill ')).split()[-1])
 except (OSError, StopIteration):return None

def resources():
 out={'allPssKiB':0,'browserPssKiB':0,'rendererMaxRssKiB':0,'gpuMaxRssKiB':0,
      'processes':0,'pssDenied':[],'roles':{},'availableKiB':psutil.virtual_memory().available//1024}
 for p in [root]+root.children(recursive=True):
  try:
   args=p.cmdline();rss=p.memory_info().rss//1024;out['processes']+=1
   is_browser=any('headless_shell' in a or 'chrome-headless-shell' in a for a in args[:1])
   role=next((a[7:] for a in args if a.startswith('--type=')),'browser' if is_browser else p.name())
   if is_browser and role=='renderer':out['rendererMaxRssKiB']=max(out['rendererMaxRssKiB'],rss)
   if is_browser and role=='gpu-process':out['gpuMaxRssKiB']=max(out['gpuMaxRssKiB'],rss)
   try:pss=p.memory_full_info().pss//1024
   except psutil.AccessDenied:
    out['pssDenied'].append([role,rss]);continue
   out['allPssKiB']+=pss
   if is_browser:out['browserPssKiB']+=pss
   out['roles'][role]=out['roles'].get(role,0)+pss
  except (psutil.NoSuchProcess,FileNotFoundError):pass
 return out

class Handler(http.server.SimpleHTTPRequestHandler):
 def log_message(self,fmt,*args):pass

report={'mode':MODE,'viewport':[W,H],'case':run_id,'browserSource':'normal visual gate Chromium launch, context and freeze CSS','shots':[]}
def blob(path):
 data=path.read_bytes();return hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest()
report['sourceCommit']=os.environ.get('DNBOX_MANUAL_INPUT_COMMIT','f868dea604256d29fef6024326b0c208cd86f3fe')
report['captureHarnessBlob']=blob(SOURCE/'tests/visual/manual_capture.py' if MODE=='candidate' else BASE/'baseline.py') if MODE!='native' else None
report['packages']={key:version(key) for key in ('playwright','numpy','Pillow','psutil')}
report['inputGitObjects']=json.loads(Path(os.environ.get('DNBOX_MANUAL_INPUT_OBJECTS',BASE/'input-objects.json')).read_text())
try:
 with http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=SOURCE/'web')) as srv:
  threading.Thread(target=srv.serve_forever,daemon=True).start()
  with sync_playwright() as pw:
   # Only select the viewport for this single comparison. All native context options come from the gate.
   gate.SIZES=[(W,H)]
   with contextlib.closing(gate.viewport_contexts(pw)) as sizes:
    _,_,ctx=next(sizes);page=ctx.new_page()
    report['browser']=ctx.browser.version
    page.goto(f'http://127.0.0.1:{srv.server_port}/product-site/manual/original/index.html')
    page.add_style_tag(content=gate.FREEZE_CSS);page.evaluate('document.fonts.ready')
    page.wait_for_load_state('networkidle');page.wait_for_timeout(250)
    report['before']=candidate.manual_state(page,30000)
    watch=Observe(page);stop=threading.Event();sample_event=threading.Event();samples=[];monitor_start=time.monotonic()
    def monitor():
     while not stop.is_set():
      sample=resources();sample['at']=round(time.monotonic()-monitor_start,4);samples.append(sample);sample_event.set()
      stop.wait(.2)
    oom_before=oom();mt=threading.Thread(target=monitor,daemon=True);mt.start();sample_event.wait()
    watch.start=time.monotonic()
    try:
     if MODE=='native':png=watch.screenshot(full_page=True,timeout=30000)
     elif MODE=='baseline':png=old.capture_original_manual(watch)
     elif MODE=='candidate':png=candidate.capture_original_manual(watch)
     else:raise ValueError(MODE)
    finally:
     report['seconds']=round(time.monotonic()-watch.start,4)
     report['shots']=watch.shots
     stop.set();mt.join()
     report['samples']=len(samples);report['memorySamples']=samples;report['peak']={k:max(s[k] for s in samples) for k in ['allPssKiB','browserPssKiB','rendererMaxRssKiB','gpuMaxRssKiB','processes']}
     report['minAvailableKiB']=min(s['availableKiB'] for s in samples)
     report['oom']=[oom_before,oom()]
    report['after']=candidate.manual_state(page,30000)
    with Image.open(io.BytesIO(png)) as im:
     report['imageSize']=list(im.size);report['modePNG']=im.mode;im.verify()
    assert report['imageSize']==[report['before']['width'],report['before']['height']]
    assert all(report['before'][k]==report['after'][k] for k in ['width','viewport','fonts','images'])
    (out/(stem+'.png')).write_bytes(png)
    report['pngBytes']=len(png);report['pngSha256']=hashlib.sha256(png).hexdigest()
    report['ok']=True
except Exception as e:
 report['ok']=False; report['error']=traceback.format_exc()
finally:
 (out/(stem+'.json')).write_text(json.dumps(report,indent=2)+'\n')
 print(stem,report['ok'],report.get('seconds'),report.get('peak'),str(report.get('error',''))[-220:],flush=True)
sys.exit(0 if report['ok'] else 1)
