"""Run desktop first, then the other three sizes, using a single native browser at a time."""
import json,subprocess,sys
from pathlib import Path
base=Path(__file__).resolve().parent;out=base/'proof';out.mkdir(exist_ok=True);run=sys.argv[1]
viewports=[(1440,900),(1024,640),(844,390),(390,844)]
for width,height in viewports:
 for mode in ('native','candidate','baseline'):
  cmd=[sys.executable,str(base/'live.py'),mode,str(width),str(height),run]
  rc=subprocess.run(cmd).returncode
  if rc and mode=='candidate':print('Candidate failed under unchanged deadline; qualification stopped.',flush=True);sys.exit(rc)
  if rc:print('Retaining original control failure', mode,width,height,flush=True)
 for compare in ('candidate','baseline'):
  left=f'{run}-native-{width}x{height}';right=f'{run}-{compare}-{width}x{height}'
  if (out/(left+'.png')).exists() and (out/(right+'.png')).exists():
   a=subprocess.run([sys.executable,str(base/'compare.py'),left,right],capture_output=True,text=True)
   print(a.stdout,a.stderr,flush=True)
   if a.returncode:sys.exit(a.returncode)
   with (out/f'{run}-comparisons.jsonl').open('a') as f:f.write(a.stdout)
 if width==1440 and (out/f'{run}-native-{width}x{height}.png').exists():
  # Recheck the most expensive route on fresh processes with the method order reversed.
  for variant in ('baseline','candidate'):
   repeat_run=run+'-repeat'
   rc=subprocess.run([sys.executable,str(base/'live.py'),variant,str(width),str(height),repeat_run]).returncode
   if rc and variant=='candidate':sys.exit(rc)
   if rc:continue
   left=f'{run}-native-{width}x{height}';right=f'{repeat_run}-{variant}-{width}x{height}'
   check=subprocess.run([sys.executable,str(base/'compare.py'),left,right],capture_output=True,text=True)
   print(check.stdout,check.stderr,flush=True)
   if check.returncode:sys.exit(check.returncode)
   with (out/f'{run}-comparisons.jsonl').open('a') as f:f.write(check.stdout)
   (out/(right+'.png')).unlink(missing_ok=True)
 for mode in ('native','candidate','baseline'):
  (out/f'{run}-{mode}-{width}x{height}.png').unlink(missing_ok=True)
